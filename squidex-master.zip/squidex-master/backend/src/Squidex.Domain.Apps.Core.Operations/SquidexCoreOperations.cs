﻿// ==========================================================================
//  Squidex Headless CMS
// ==========================================================================
//  Copyright (c) Squidex UG (haftungsbeschraenkt)
//  All rights reserved. Licensed under the MIT license.
// ==========================================================================

using System.Reflection;

namespace Squidex.Domain.Apps.Core
{
    public static class SquidexCoreOperations
    {
        public static readonly Assembly Assembly = typeof(SquidexCoreOperations).Assembly;
    }
}
