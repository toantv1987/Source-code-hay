---
name: Development Task or Bug
about: Bugs when developing Squidex or when writing custom extensions
title: ''
labels: ''
assignees: ''

---

Do NOT USE issues for 

* Bug reports
* Hosting Questions
* Feature Requests
* anything that is not related to development.

Please post your issues or questions in our support forum: https://support.squidex.io/. You can use your Github account to login.
