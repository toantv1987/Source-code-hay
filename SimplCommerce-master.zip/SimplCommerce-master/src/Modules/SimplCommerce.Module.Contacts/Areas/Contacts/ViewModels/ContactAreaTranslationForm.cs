﻿namespace SimplCommerce.Module.Contacts.Areas.Contacts.ViewModels
{
    public class ContactAreaTranslationForm
    {
        public string DefaultCultureName { get; set; }

        public string Name { get; set; }
    }
}
