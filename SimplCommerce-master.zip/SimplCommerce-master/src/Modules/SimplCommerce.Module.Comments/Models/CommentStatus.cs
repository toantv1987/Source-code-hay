﻿namespace SimplCommerce.Module.Comments.Models
{
    public enum CommentStatus
    {
        Pending = 1,

        Approved = 5,

        NotApproved = 8
    }
}
