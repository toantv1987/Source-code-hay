﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class ProductDetailAttribute
    {
        public string Name { get; set; }

        public string Value { get; set; }
    }
}
