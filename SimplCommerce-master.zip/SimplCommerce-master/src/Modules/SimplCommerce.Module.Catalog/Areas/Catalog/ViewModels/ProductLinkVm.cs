﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class ProductLinkVm
    {
        public long Id { get; set; }

        public string Name { get; set; }

        public bool IsPublished { get; set; }
    }
}
