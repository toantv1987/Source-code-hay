﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class ProductOptionCombinationVm
    {
        public long OptionId { get; set; }

        public string OptionName { get; set; }

        public string Value { get; set; }

        public int SortIndex { get; set; }
    }
}
