﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class ProductOptionValueVm
    {
        public string Key { get; set; }

        public string Display { get; set; }
    }
}
