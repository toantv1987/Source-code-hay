﻿using SimplCommerce.Module.Core.Areas.Core.ViewModels;

namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class SimpleProductWidgetForm : WidgetFormBase
    {
        public SimpleProductWidgetSetting Setting { get; set; }
    }
}
