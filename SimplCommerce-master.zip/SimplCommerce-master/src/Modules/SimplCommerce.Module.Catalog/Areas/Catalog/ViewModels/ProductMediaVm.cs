﻿namespace SimplCommerce.Module.Catalog.Areas.Catalog.ViewModels
{
    public class ProductMediaVm
    {
        public long Id { get; set; }

        public string Caption { get; set; }

        public string MediaUrl { get; set; }
    }
}
