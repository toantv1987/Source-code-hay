﻿using SimplCommerce.Module.Catalog.Models;

namespace SimplCommerce.Module.Catalog.Data
{
    public interface IProductTemplateProductAttributeRepository
    {
        void Remove(ProductTemplateProductAttribute item);
    }
}
