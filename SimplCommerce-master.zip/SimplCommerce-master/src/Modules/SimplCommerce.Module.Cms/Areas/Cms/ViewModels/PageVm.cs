﻿namespace SimplCommerce.Module.Cms.Areas.Cms.ViewModels
{
    public class PageVm
    {
        public string Name { get; set; }

        public string Body { get; set; }

        public string MetaTitle { get; set; }

        public string MetaKeywords { get; set; }

        public string MetaDescription { get; set; }
    }
}
