﻿namespace SimplCommerce.Module.Cms.Areas.Cms.ViewModels
{
    public class PageTranslationForm
    {
        public string DefaultCultureName { get; set; }

        public string Name { get; set; }

        public string Body { get; set; }
    }
}
