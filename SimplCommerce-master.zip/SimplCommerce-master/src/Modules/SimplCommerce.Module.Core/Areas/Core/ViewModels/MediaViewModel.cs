﻿namespace SimplCommerce.Module.Core.Areas.Core.ViewModels
{
    public class MediaViewModel
    {
        public string Url { get; set; }

        public string ThumbnailUrl { get; set; }
    }
}
