﻿namespace SimplCommerce.Module.Core.Models
{
    public class SimplConstants
    {
        public const string ThemeConfigKey = "Theme";
    }
}
