﻿namespace SimplCommerce.Module.Core.Models
{
    public class WidgetZoneIds
    {
        public static long HomeFeatured = 1;

        public static long HomeMainContent = 2;

        public static long HomeAfterMainContent = 3;
    }
}
