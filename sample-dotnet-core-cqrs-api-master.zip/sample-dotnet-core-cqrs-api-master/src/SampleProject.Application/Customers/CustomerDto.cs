﻿using System;

namespace SampleProject.Application.Customers
{
    public class CustomerDto
    {
        public Guid Id { get; set; }
    }
}