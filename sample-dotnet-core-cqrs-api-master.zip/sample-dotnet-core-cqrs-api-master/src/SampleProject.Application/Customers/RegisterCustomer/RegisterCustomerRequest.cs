﻿namespace SampleProject.Application.Customers.RegisterCustomer
{
    public class RegisterCustomerRequest
    {
        public string Email { get; set; }

        public string Name { get; set; }
    }
}