﻿namespace SampleProject.Application.Configuration.Emails
{
    public class EmailsSettings
    {
        public string FromAddressEmail { get; set; }
    }
}