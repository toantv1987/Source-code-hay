﻿namespace SampleProject.Infrastructure.Processing.Outbox
{
    public interface IRecurringCommand
    {

    }
}