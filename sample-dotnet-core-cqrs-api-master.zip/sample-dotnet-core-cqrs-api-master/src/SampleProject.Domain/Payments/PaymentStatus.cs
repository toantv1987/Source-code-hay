﻿namespace SampleProject.Domain.Payments
{
    public enum PaymentStatus
    {
        ToPay = 0,
        Paid = 1,
        Overdue = 2
    }
}