﻿namespace SampleProject.Domain.SeedWork
{
    public interface IAggregateRoot
    {
        
    }
}