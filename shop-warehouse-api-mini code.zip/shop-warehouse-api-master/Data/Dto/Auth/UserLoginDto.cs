﻿namespace ShopWarehouse.API.Data.Dto.Auth
{
    public class UserLoginDto
    {
        public string Username { get; set; }
        public string Password { get; set; }

    }
}
