import React from 'react';
import Layout from './Layout'

export const PrivatePage = () => {
    return (
        <Layout />
    );
};