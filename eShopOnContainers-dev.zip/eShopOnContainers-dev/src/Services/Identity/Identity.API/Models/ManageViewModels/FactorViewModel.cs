﻿namespace Microsoft.eShopOnContainers.Services.Identity.API.Models.ManageViewModels
{
    public record FactorViewModel
    {
        public string Purpose { get; init; }
    }
}
