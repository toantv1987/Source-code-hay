﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pos.Event.Contracts
{
    public class AppGlobalTopic
    {
        public static string PosTopic = "PosServices";
    }
}
