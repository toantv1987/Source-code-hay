﻿using System;

namespace Pos.Report.Infrastructure
{
    public class Class1
    {
    }
}
