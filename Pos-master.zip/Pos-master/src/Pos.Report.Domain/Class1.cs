﻿using System;

namespace Pos.Report.Domain
{
    public class Class1
    {
    }
}
