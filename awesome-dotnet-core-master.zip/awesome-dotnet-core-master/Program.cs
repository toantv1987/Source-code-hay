using System;

namespace AwesomeDotNetCore
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("This is C# repository.");
        }
    }
}