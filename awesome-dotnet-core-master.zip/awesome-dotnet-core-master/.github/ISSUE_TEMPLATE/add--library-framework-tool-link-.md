---
name: Add [LIBRARY/FRAMEWORK/TOOL/LINK]
about: Describe this issue template's purpose here.
title: ''
labels: In Preview
assignees: thangchung

---

1. Have your repository in Github or any source control been created at least 3 months? 

> We review by going to your repository to verify the first file you're created, but the process might take time so please help to declare here, then it will be easy for all reviewers

[You answer]

2. The reason you think your library/framework/tooling/link is awesome?

> This is to prevent some of library or framework is too small in size and famous level which help this awesome list becomes a reliable references for .NET community

[You answer]

3. Have your PR follows up with alphabet-ordering?

> Help to strictly check the alphabet-ordering before you submit the PR so that will be helpful for .NET Community easy to find the library/framework/tooling/link that they need

3. Is it .NET Core or .NET Standard?
[You answer]

4. Have you read through the README or issues list to make sure that your PR is not duplicated to any others?
[You answer]
