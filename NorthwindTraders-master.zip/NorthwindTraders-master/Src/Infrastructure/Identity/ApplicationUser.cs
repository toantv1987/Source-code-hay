﻿using Microsoft.AspNetCore.Identity;

namespace Northwind.Infrastructure.Identity
{
    public class ApplicationUser : IdentityUser
    {
    }
}
