#!/bin/bash
/opt/mssql/bin/sqlservr & /init.sh