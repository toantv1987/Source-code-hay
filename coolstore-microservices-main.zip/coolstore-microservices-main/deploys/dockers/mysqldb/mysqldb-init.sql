CREATE DATABASE maindb;
USE maindb;