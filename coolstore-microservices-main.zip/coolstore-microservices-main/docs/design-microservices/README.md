# Microservices Design

## API Design

> TODO

## API Gateways

> TODO

## Interservice Communication

> TODO
