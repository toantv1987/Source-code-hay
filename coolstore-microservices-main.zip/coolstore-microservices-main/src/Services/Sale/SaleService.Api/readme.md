
```bash
curl -X POST http://localhost:5000/sale/update-order-status -H "Content-Type: application/json" -d "{ \"orderId\": \"65e1b2f2-2c73-4906-aa91-bdf888420ed6\", \"orderStatus\": 0 }"
```
