namespace SaleService.Domain.Model
{
    public enum OrderStatus
    {
        Received,
        Processing,
        Complete
    }
}
