namespace SaleService
{
    public class Anchor
    {
    }
}
