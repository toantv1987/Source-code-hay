// using System.Collections.Generic;
// using FluentValidation;
// using MediatR;
// using N8T.Infrastructure.App.Dtos;
//
// namespace ShoppingCartService.Application.GetShoppingCartWithProducts
// {
//     public class GetShoppingCartWithProductsQuery : IRequest<IEnumerable<FlatCartDto>>
//     {
//     }
//
//     public class GetShoppingCartWithProductsValidator : AbstractValidator<GetShoppingCartWithProductsQuery>
//     {
//         public GetShoppingCartWithProductsValidator()
//         {
//         }
//     }
// }
