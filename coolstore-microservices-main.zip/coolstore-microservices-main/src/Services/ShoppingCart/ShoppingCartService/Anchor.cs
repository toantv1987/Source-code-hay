namespace ShoppingCartService
{
    public class Anchor
    {
    }
}
