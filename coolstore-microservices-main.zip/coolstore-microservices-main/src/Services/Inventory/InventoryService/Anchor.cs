namespace InventoryService
{
    public class Anchor
    {
    }
}
