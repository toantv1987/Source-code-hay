dotnet ef migrations add InitialInventoryDb -c MainDbContext -o Infrastructure/Data/Migrations
