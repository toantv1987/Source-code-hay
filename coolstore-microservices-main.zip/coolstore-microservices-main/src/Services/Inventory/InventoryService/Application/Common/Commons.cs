namespace InventoryService.Application.Common
{
}
