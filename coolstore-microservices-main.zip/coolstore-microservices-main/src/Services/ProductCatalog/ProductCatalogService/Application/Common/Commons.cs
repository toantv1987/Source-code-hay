namespace ProductCatalogService.Application.Common
{
    public record SearchAggsByTagsDto(string Key, int Count);
}
