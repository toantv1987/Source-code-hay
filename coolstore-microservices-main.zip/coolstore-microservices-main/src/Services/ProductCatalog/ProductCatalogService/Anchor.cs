namespace ProductCatalogService
{
    public class Anchor
    {
    }
}
