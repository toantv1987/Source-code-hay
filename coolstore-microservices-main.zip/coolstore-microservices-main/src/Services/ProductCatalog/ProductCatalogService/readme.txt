dotnet ef migrations add InitialProductionDb -c MainDbContext -o Infrastructure/Data/Migrations
