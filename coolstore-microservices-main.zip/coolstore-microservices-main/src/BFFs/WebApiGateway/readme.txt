// waiting for propagating trace traceparent attribute PR => DONE
https://github.com/microsoft/reverse-proxy/pull/456
