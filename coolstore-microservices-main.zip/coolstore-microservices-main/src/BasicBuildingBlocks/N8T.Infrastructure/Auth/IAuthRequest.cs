using Microsoft.AspNetCore.Authorization;

namespace N8T.Infrastructure.Auth
{
    public interface IAuthRequest : IAuthorizationRequirement
    {
    }
}
