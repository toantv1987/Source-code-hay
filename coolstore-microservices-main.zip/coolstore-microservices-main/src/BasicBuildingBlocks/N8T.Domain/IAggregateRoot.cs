﻿namespace N8T.Domain
{
    public interface IAggregateRoot
    {
    }
}