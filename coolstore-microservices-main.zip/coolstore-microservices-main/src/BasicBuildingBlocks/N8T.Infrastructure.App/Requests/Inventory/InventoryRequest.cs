using System;

namespace N8T.Infrastructure.App.Requests.Inventory
{
    public class InventoryRequest
    {
        public Guid InventoryId { get; set; }
    }
}
