namespace N8T.Infrastructure.App.Requests.Identity
{
    public class UserByIdRequest
    {
        public string UserId { get; set; } = default!;
    }
}
