using System;

namespace N8T.Infrastructure.App.Requests.ProductCatalog
{
    public class ProductByIdRequest
    {
        public Guid Id { get; set; }
    }
}
