namespace N8T.Infrastructure.OTel.MediatR
{
    public class OTelMediatROptions
    {
        public static string OTelMediatRName = "Otel.MediatR";
    }
}
