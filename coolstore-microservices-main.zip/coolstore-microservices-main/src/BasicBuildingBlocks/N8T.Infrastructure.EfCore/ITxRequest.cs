namespace N8T.Infrastructure.EfCore
{
    public interface ITxRequest
    {
    }
}
