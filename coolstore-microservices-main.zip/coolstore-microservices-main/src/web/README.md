# Get starting

Create .env at the root of project

```
PORT=31999
REACT_APP_AUTHORITY=http://localhost:31888
REACT_APP_API=http://localhost:31666
```

Then run the command

```bash
$ npm start
```