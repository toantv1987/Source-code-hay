import React from 'react'

export default () => {
  return <div>Not authenticated...</div>
}
