import React from 'react'

export default () => {
  return (
    <div>
      Not found...Wanna go <a href="/">home</a>?
    </div>
  )
}
