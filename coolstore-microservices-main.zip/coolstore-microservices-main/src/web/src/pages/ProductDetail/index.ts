export { default } from './ProductDetail'
