
//
// Setting up a common event bus
// for all Vue apps in Piranha
//
Vue.prototype.eventBus = new Vue();