namespace Blogifier.Shared
{
    public class PostVisit
    {
        public string Name { get; set; }
        public int Value { get; set; }
    }
}
