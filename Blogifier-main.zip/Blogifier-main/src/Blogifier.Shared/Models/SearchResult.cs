﻿namespace Blogifier.Shared
{
	public class SearchResult
   {
      public int Rank { get; set; }
      public PostItem Item { get; set; }
   }
}
