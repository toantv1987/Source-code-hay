namespace Blogifier.Shared
{
    public class OptionItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
    }
}
