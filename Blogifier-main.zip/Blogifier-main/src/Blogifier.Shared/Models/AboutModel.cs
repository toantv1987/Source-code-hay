namespace Blogifier.Shared
{
	public class AboutModel
	{
		public string Version { get; set; }
		public string OperatingSystem { get; set; }
        public string DatabaseProvider { get; set; }
	}
}
