# Security Policy

## Supported Versions

Security patches will be applied to the most recent version.

| Version | Supported           |
| ------- | ------------------  |
| 2.9.x.x | Most Current Version|

## Reporting a Vulnerability

Please report (suspected) security vulnerabilities to
**[blogifierdotnet@gmail.com](mailto:blogifierdotnet@gmail.com)**. 
