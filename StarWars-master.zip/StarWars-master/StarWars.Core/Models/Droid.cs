﻿namespace StarWars.Core.Models
{
    public class Droid : Character
    {
        public string PrimaryFunction { get; set; }
    }
}
