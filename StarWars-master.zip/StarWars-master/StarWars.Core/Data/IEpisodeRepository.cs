﻿using StarWars.Core.Models;

namespace StarWars.Core.Data
{
    public interface IEpisodeRepository : IBaseRepository<Episode, int> { }
}
