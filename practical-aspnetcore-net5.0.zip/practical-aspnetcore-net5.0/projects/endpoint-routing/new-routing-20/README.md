# Convention based Routing
        
Use `IEndpointRouteBuilder.MapControllerRoute` to configure convention based routing.