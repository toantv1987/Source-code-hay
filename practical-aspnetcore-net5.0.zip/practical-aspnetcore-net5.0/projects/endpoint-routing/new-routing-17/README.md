# New Routing - enable MVC but without Views support or Razor Page.  

Using `services.AddControllers` to provide MVC without Views supports. Perfect for Web APIs.