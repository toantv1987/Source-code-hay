# New Routing - enable Razor Pages with MVC API support

`services.AddRazorPages()` add supports for Razor Pages and MVC API (click to fetch a GET API).