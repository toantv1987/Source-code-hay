# New Routing - Static file fallback

Return a static page when your request does not match anything else using `MapFallbackToFile`.