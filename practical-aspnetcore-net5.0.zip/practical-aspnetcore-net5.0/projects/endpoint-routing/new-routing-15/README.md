# New Routing - Attaching Metadata information to your inline Middleware

Use `IEndpointConventionBuilder.WithMetadata` to attach metadata information to your inline Middleware.