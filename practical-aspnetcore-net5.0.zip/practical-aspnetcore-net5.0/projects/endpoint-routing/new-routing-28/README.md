# New Routing - Setup a Razor Page Area

This sample shows you how to setup a Razor Pages area.

You need to create the following folders structure `Areas/<Your Area>/Pages/Index.cshtml` e.g. `Areas/Admin/Pages/Index.cshtml`. This page will be accessible via `/Admin/`.