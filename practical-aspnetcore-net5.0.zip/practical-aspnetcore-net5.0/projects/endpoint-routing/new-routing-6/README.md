# New Routing - interrogate available endpoints in your app

Use `route.DataSources` to interrogate all the available endpoints in your app. It's really handy.