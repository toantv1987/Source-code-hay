# New Routing - Obtaining an Endpoint metadata from your MVC Controller

Obtain Endpoint metadata from MVC Controller's Action methods.