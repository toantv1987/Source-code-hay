# Host Matching on your middleware

This example demonstrates on how to configure your endpoint to respond to a request from a specific host. In this example, GET `/` returns a different result depending whether you access it from `localhost:8111` and `localhost:8112`.

**Run this sample through command line `dotnet watch run`**.