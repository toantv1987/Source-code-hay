# New Routing - enable MVC but with Views support but without Razor Page

Using `services.AddControllersWithViews();` to provide MVC with Views supports. Razor Page is not available. So this similar to the "classic" MVC configuration.