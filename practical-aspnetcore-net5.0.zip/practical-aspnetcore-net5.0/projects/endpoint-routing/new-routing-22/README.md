# Configure Kestrel defaults for Endpoints

We configure `KestrelServerOptions.ConfigureEndpointDefaults` so the Endpoints will run only on HTTP/2.

You can only access this sample over HTTPS. Hence use `https://localhost:5001/` instead of `http://localhost:5000/`.
