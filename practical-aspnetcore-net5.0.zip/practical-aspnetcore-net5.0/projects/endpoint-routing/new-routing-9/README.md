# New Routing - Razor Page fallback

Return a Razor Page when your request does not match anything else using `MapFallbackToPage`.