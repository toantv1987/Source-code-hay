# New Routing - Map a route to a Razor Pages located in Areas

Map a route to a Razor Pages located in an Area using `Conventions.AddAreaPageRoute`.