# New Routing - use RequestDelegate directly

This example shows how to use `RequestDelegate` directly in `app.UseRouting` for `GET` operation using `MapGet`. `MapPost`, `MapPut`, and `MapDelete` are also available for use.