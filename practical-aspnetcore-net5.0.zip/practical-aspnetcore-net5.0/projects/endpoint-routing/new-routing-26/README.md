# Handle Razor Pages route dynamically

This example shows how to handle Razor Pages routing dynamically using `MapDynamicPageRoute` and `DynamicRouteValueTransformer`.

This will allows you to process a given url pattern and then set values to the `RouteValueDictionary` as you see fit.