# New Routing - Obtaining an Endpoint metadata from your Razor Page

  Use the brand new `EndPoint.Metadata.GetMetadata<>()` to get values from attributes at your Razor Page.