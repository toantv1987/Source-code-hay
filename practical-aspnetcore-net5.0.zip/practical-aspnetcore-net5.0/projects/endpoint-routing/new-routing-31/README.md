# Allow anonymous access and require authorization to endpoints

  Use `.AllowAnonymous()` and `.RequireAuthorization` extension methods to allow anonymous access and demand authorization.