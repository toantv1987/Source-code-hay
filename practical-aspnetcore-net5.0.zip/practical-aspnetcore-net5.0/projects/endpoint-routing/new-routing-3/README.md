# New Routing - enable just MVC 

This example shows how to enable *just* MVC with **default** (`{controller=Home}/{action=Index}/{id?}`) route in your app using the method `app.UseRouting`. Razor Pages won't work at all in this sample.