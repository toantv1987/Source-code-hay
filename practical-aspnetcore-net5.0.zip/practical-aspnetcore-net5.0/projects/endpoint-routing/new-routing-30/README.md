# New Routing - Fallback page for Razor Pages areas with route patterns

This sample shows how to return different fallback page located in areas depending on the route pattern that matches the request.