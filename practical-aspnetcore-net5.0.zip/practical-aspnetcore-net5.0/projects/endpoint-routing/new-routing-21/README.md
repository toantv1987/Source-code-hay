# A new way to map health check
        
Use `IEndpointRouteBuilder.MapHealthChecks` to configure health check instead of `IApplicationBuilder.UseHealthChecks`. [This is how it's done in ASP.NET Core 2.2](/practical-aspnetcore/blob/master/projects/2-2/health-check/src/Program.cs).

