# New Routing - Map Areas by Convention

Use `IEndpointRouteBuilder.MapAreaControllerRoute` to configure routing for your areas.