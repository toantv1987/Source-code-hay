# New Routing - enable just Razor Pages

This example shows how to enable *just* Razor Pages routes in your app using the method `app.UseRouting`. MVC Controllers won't work at all in this sample.