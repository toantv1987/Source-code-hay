# New Routing - Obtaining an Endpoint from your Middleware

Use the brand new `HttpContext.GetEndPoint` extension method to examine the current endpoint that is being executed.