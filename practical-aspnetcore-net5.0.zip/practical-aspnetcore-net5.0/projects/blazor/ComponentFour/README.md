# Handling component paramater for event handling using EventCallback<T>

This is new on Blazor 0.9. For a complete discussion on this topic, this is a useful [thread](https://github.com/aspnet/AspNetCore/issues/6351).