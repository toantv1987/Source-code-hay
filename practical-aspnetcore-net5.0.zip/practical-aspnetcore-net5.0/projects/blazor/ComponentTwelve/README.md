# Splatting arbitrary attributes to components using @attributes 

Use `@attributes` and a `Dictionary<string, object>` or `List<KeyValuePair<string, object>>`.