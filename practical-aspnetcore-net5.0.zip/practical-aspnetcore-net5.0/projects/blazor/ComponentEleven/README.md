# Accept arbitrary parameters

Use `[Parameter(CaptureUnmatchedValues = true)]` to capture unmatched parameters.