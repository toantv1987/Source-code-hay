# Splatting arbitrary attributes to components using @attributes

This sample demonstrates the usage of `@attributes` attributes splatting on a form input.
