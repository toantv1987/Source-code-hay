# Different ways to pass data to a component

This sample demonstrates the various ways to pass parameters to a component and how it affects on how the data is perceived by the component.
