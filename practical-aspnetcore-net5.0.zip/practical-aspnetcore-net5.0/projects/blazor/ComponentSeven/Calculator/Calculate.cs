
namespace Calculator
{
    public class Calculate
    {
        public int Double(int number) => number * 2;
    }
}