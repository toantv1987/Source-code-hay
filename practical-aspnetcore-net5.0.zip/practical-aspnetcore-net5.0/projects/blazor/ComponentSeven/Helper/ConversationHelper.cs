
namespace ComponentSeven.Helper
{
    public static class ConversationHelper
    {
        public static string Say() => "Hello";
    }
}