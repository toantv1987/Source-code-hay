# Logging (3)

* [Basic Logging](/projects/logging/logging-1)

  Now you configure logging at `Program` instead of `Startup.Configure` via `ConfigureLogging`. 

* [Logging filtering](/projects/logging/logging-2)

  Now you can adjust what kind of logging information from various part of ASP.NET Core and your app you want show/stored.

* [JSON Console Logger](/projects/logging/logging-3)

  This example shows how to display log to console in structured JSON logs.