# Emit structured JSON logs in console

This example shows how to display log to console in structured JSON logs.