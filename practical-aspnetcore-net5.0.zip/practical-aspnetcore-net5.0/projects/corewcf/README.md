# CoreWCF (1)

* [Hello world with simple HTTP](/projects/corewcf/corewcf-1)
  This sample shows a simple request/response CoreWCF flow.

## Note

The clients are built with the WCF Client libraries available [here](https://github.com/dotnet/wcf).