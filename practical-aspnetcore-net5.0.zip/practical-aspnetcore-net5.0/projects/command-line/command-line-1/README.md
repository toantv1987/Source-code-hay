# System.Commandline 

This example shows how to integrate `System.Commandline` amazing command line parsing capability with your ASP.NET Core app.

You can run this sample by calling `dotnet watch run --port 5500`. The port option allows you to specify which port you want Kestrel listens to.