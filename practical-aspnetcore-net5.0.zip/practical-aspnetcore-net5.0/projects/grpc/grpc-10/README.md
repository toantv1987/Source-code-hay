# gRPC-Web Hello World

This sample demonstrate a simple Unary RPC. The client side is located on `client` folder and the server at the `server` folder. Make sure you run the server **first** before running the client.

The copies of `billboard.proto` on both folders are identical.

You will notice that the server is running on HTTP 1.1 instead of HTTP 2.0.