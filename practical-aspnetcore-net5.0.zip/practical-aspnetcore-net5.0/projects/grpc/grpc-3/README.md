# gRPC Client Streaming

This is a sample of gRPC [Client Streaming](https://grpc.io/docs/guides/concepts/). In this case the client is sending a list of fortune cookies messages and the server convert them to "Friends' In Bed" version cookie and send it back to the client at the end of the streaming.
