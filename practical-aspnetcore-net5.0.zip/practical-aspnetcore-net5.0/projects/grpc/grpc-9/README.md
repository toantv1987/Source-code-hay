# gRPC Server Streaming

This gRPC server streams a picture of a kitty to the client. 'Nuff said.