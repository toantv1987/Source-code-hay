# gRPC-Web Server Streaming

This is a sample of gRPC-Web [Server Streaming](https://grpc.io/docs/guides/concepts/). In this case the server just repeat the same message 10 times every 5 seconds. Make sure you run both the server and the client.

The server is running on HTTP 1.1 instead of HTTP 2.

The client is a Blazor Web Assembly application.