# Sending nested types and repeated values (list)

This sample shows how to define Protocol Buffers format to support sending nested types and repeated values (list).
