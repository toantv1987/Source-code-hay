# Sending enum, string and datetime values

This sample shows how to define Protocol Buffers format to support sending enum, string and datetime.
