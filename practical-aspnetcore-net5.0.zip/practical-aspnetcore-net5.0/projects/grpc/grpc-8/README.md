# Using oneof type to simulate nullable value

`oneof` type allows you check whether the value of a property is set or not, essentialy emulating nullable type.
