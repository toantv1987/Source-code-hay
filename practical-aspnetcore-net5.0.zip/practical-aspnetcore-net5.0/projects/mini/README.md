# Mini Apps (1)

This is a collection of useful mini applications written in ASP.NET Core 5 designed to demonstrate one or more techniques related to ASP.NET Core and other web libraries.


- [PDF Viewer](pdf-viewer)

  This sample shows you how to build a PDF viewer using PDF.js