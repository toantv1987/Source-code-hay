# JS Integration 

This sample shows how to access JavaScript functions available at `windows` global scope.
