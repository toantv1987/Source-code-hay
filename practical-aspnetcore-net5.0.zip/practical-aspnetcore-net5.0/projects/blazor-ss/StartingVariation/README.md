# Starting Variations

In this example we demonstrates how three different Razor Pages endpoints act as starting points for different path of your Server Side Blazor. 
