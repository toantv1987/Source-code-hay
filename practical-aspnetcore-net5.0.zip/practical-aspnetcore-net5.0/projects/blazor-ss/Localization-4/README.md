# LTR and RTL support

This sample shows how to implement LTR/RTL support in Blazor Server. This sample uses Portable Object (PO) files for localization. 

We will be using `OrchardCore.Localization.Core` package with version `1.0.0-rc1-13433`.

For this example to work, you need to add additional NuGet sources using [this instruction](https://cloudsmith.io/~orchardcore/repos/preview/setup/#formats-nuget).
