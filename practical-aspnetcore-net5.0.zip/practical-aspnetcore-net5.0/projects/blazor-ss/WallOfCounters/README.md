# Wall of Counters

This is a sample on how to use System.Timers.Timers with Blazor and how to update the UI from another thread.

This sample also uses [BlazorStyle](https://github.com/chanan/BlazorStyled), a component that allows to use scoped CSS inside a Blazer component (similar to Vue Single File Component).