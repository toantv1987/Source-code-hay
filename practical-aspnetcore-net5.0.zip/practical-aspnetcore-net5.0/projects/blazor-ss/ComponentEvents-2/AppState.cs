using System;

namespace ComponentEvents
{
  public class NotificationMessage 
  {
    public string Message { get; set; }
  }
}