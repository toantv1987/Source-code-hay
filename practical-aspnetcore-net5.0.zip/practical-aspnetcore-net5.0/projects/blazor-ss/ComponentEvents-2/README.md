# Component Events 2

The sample is similar to [Component Events](ComponentEvents) except that it uses [Blazor.EventAggregrator](https://github.com/mikoskinen/Blazor.EventAggregator) to handle cross components and pages communication. 