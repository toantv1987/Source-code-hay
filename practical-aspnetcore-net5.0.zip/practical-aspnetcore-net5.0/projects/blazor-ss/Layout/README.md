# Layouts

This sample shows how to use layout and nested layouts (including multiple nested layout) with your Razor Component app.
