# ChatR

This sample shows how to host SignalR Hub along with Blazor Server Side. This is just a simple 'chat' app that uses SignalR to broadcast everything. 