# Localization

This is a sample on how to use localization and perform language switching on Blazor Server by using a global resource.