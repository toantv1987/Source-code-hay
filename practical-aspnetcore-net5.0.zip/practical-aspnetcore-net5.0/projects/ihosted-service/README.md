# IHostedService (2)

* [Background Task](/projects/ihosted-service/ihosted-service-1)

  Implement background tasks using the new `IHostedService` interface.

* [Background Task - 2](/projects/ihosted-service/ihosted-service-2)

  Implement background tasks using the new `IHostedService` interface and a timer. This example comes from the technique outlined in this [ASP.NET Core documentation](https://docs.microsoft.com/en-us/aspnet/core/fundamentals/host/hosted-services). 
