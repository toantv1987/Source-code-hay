# Background Service with Timer

  Implement background tasks using the new `IHostedService` interface and a timer. This example comes from the technique outlined in this [ASP.NET Core documentation](https://docs.microsoft.com/en-us/aspnet/core/fundamentals/host/hosted-services). 
