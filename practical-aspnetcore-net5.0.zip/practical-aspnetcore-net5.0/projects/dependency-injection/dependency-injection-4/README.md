# Use Lazy type in Microsoft Dependency Injection

This example shows how to register types encapsulated using [Lazy Type](https://docs.microsoft.com/en-us/dotnet/api/system.lazy-1?view=net-5.0). This is very useful if you are registering large or resource-intensive object.