# Serialize anonymous type using JsonSerializer.SerializeAsync

You can also just create adhoc JSON document using anonymous type. 