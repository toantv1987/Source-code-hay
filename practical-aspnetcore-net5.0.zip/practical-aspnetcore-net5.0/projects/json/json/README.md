# New System.Text.Json library

Use `JsonSerializer.SerializeAsync` to serialize your object to json directly to stream. 