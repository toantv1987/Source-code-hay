# Snake Case Json Naming Policy

Create a custom naming policy that generate JSON property names in snake_case.

Code for converting CamelCase property to snake_case is obtained from [Newtonsoft.Json](https://github.com/JamesNK/Newtonsoft.Json/blob/cdf10151d507d497a3f9a71d36d544b199f73435/Src/Newtonsoft.Json/Utilities/StringUtils.cs).