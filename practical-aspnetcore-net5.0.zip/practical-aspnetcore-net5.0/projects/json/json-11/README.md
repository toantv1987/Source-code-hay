# Custom Converter 

This is an custom converter implementation for DateTime type for JsonSerializer in the format of JSON date ticks. Much of the code comes from this [Tweet](https://twitter.com/James_M_South/status/1268102226490384385).

More code also comes from https://github.com/JamesNK/Newtonsoft.Json/blob/master/Src/Newtonsoft.Json/Converters/JavaScriptDateTimeConverter.cs.