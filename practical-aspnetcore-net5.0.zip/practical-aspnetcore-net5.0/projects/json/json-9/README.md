# Custom Converter 

This is an custom converter implementation for TimeSpan type for JsonSerializer. 