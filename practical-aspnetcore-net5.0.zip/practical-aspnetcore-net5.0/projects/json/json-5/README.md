# Serialization a Dictionary of object

A `Dictionary<string, object>` can be used to generate pretty much any shape of JSON document that you want.