# Build a JSON document manually

In this sample we write a JSON document to stream directly  using `Utf8JsonWriter`. The JSON document has the following properties:

* String
* Number
* Date
* An object
* An array of objects
