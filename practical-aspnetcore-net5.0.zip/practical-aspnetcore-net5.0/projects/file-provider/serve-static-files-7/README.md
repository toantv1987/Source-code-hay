# Serve static files from multiple folders

There are many scenarios where you need to serve static files from multiple folders, including those ones outside your application folder. This example shows you how.