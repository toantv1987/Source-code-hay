# Static File

This sample is really simple. It's consisted of a single line of code of `app.UseStaticFiles();` to enable full static files support.

You have to open `http://localhost:5000/index.html` instead of `http://localhost:5000/` to access the `index.html` files located at the `wwwroot` folder. 
