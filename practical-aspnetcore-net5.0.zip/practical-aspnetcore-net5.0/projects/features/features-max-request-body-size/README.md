# Feature IHttpMaxRequestBodySizeFeature 

Feature to inspect and modify the maximum request body size for a single request ([doc](https://docs.microsoft.com/en-us/dotnet/api/microsoft.aspnetcore.http.features.ihttpmaxrequestbodysizefeature?view=aspnetcore-3.1)).