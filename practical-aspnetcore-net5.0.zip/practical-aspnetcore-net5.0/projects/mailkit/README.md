# Mailkit (2)

  This section shows samples of using [MailKit](https://github.com/jstedfast/MailKit), which is essentially **the** library to use for sending and receiving email in ASP.NET Core.

  * [Send message](/projects/mailkit/mailkit-1)

    This shows an example on how to send an email.

  * [Connect to POP3 Account](/projects/mailkit/mailkit-2)
   
    Thsi shows how to connect to a POP3 account